#Palash Jain (A20430557)
#Program to Validate Visa, Master. Amarican Express and Discover Card
#HW- 3


#It Takes Even position of number. Double it and Add all Double Values
def sumofDoubleEvenPlace(number):
    lent = len(number)
    if lent >= 13 and lent <= 16:
        sum = 0
        position=len(number)-2
        while position >= 0:
            twiceValue = int(number[position]) * 2
            twiceValue = getDigit(twiceValue)
            sum = sum + twiceValue
            position -= 2

        print("Even Double sum", sum)
        return sum
    else:
        print("Invalid Card")
        return
#Sum Of Odd position Number
def sumofOddPlace ( number ):
    lent = len(number)
    if lent >= 13 and lent <= 16:
        sum = 0
        position = len(number) - 1
        while position >= 0:
            sum = sum + int(number[position])
            position -= 2

        print("odd sum", sum)
        return sum
    else:
        print("Invalid Card")
        return


#Returns True if CardNumber is Valid
def isValid(number):

   sum = int(sumofDoubleEvenPlace(number)) + int(sumofOddPlace(number))
   if(sum % 10 == 0):
       print("It is a valid Card number")
       getPrefixMatched(number)
       return
   else:
       print("It is an invalid Card number")
       return

#If Sum of Number is Double Digit, It adds the digit and Returns Single Digit
def getDigit(number):
    if number >10:
        s = 0
        while number:
            s += number % 10
            number //= 10
        return s
    else:
        return number

#It Finds out about Card Type
def getPrefixMatched(number):
    if number[0] == "4":
            cardtype = "Visa"
            print(cardtype)
    elif number[0] == "5":
            cardtype = "MasterCard"
            print(cardtype)
    elif number[0] == "3" and number[1] == "7":
            cardtype = "American Express"
            print(cardtype)
    elif number[0] == "6":
            cardtype = "Discover Card"
            print(cardtype)
    return cardtype

#It Returns First K Digit of Numbers
def getPrefix(number,k):
    if(len(number)>=k):
        d = 0
        for x in range(0, k):
            d = int(number[x]) + d * 10
        print(d)
        return d
    else:
        print("K cannot be more than length of ", number)
        return number

#Main Function is used to call Other Function
def main():
    number = input("Enter the Card Number")
    isValid(number)
    prefixInput=input("Enter the first K digit you wanna see")
    getPrefix(number,int(prefixInput))
    return
main()
