
print("Check Status Light")
color = input("Enter Green, Red or Amber")
if color == "Green":
    print("Do start Procedure")

elif color == 'Red':
        print("shut off all input line and check meter")
        meter = eval(input("Enter meter Reading"))
        if meter < 50:
            print("Check main line to test pressure")
            pressure = (input("Enter PRessire Normal, High or Low"))
            if pressure == "Normal":
                print("Refer to meter service manual")
            elif pressure == "High" or "Low":
                print("Refer to main line manual")
        else:
            print("Measure flow velocity")
            velocity = input("Enter Normal, High or Low")
            if velocity == "Normal":
                print("Refer to inlet service manual")
            else:
                print("Refer unit for factory Service")
elif color == "Amber":
    print("check fuel line service routine")
